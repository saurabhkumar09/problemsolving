/* input N=16
   output=16 11 6 1 -4 6 11 16
   geeks for geeks practice code 1*/



