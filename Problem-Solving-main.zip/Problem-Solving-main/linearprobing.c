#include<stdio.h>
#define size 11
int main()
{
 int arr[size]={0},value,index,x=1;

 while(1)
 {
  printf("enter the element to be inserted:");
  scanf("%d",&value);

  index= vlaue % size;

  if(index==0)
  {
      arr[index]=value;
  }
  else{
    while(arr[index]!=0 && index<n)
    {
        if(index<n)
        {
            arr[index]=value;
        }
        else
    }
  }
 }

}
