#include<stdio.h>
#include<string.h>
void main()
{


int c=0,i=0;
char a[100];

printf("enter the string:");
scanf("%s", a);

/*for (i = 0;a[i] != '\0';i++)
    {
        if(a[i]==' ' && a[i+1] != ' ')
        c++;
    }
    printf("Number of words in given string are: %d\n", c + 1);*/

int palin()
}
